

<?php 
	if(isset($_POST['nome']) && !empty($_POST['nome'])){
		$nome = addslashes($_POST['nome']);
        $email = addslashes($_POST['email']);
        $assunto = addslashes($_POST['assunto']);
		$msg = addslashes($_POST['mensagem']);

		$para = "andreine509@gmail.com";
		// $assunto = "Pergunta do Contato";
		$corpo = "Nome:"." ".$nome."\r\n"."email:".$email."\r\n"."mensagem:".$msg;
		$cabecalho = "From: kleberandreine@hotmail.com"."\r\n".
					"Reply-To:".$email."\r\n".
					"X-Mailer: PHP/".phpversion();

		mail($para, $assunto, $corpo, $cabecalho);
            echo "E-mail Enviado Com Sucesso!";
		exit;	
	}	
?>


<!DOCTYPE html>
<html lang="pt-BR">
	<head>
		<title>Vinicius Rodrigues</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="css.css" />
	</head>
	<body>

		
			<section id="main">
				<div class="inner">
				<!-- Two -->
					<section  class="wrapper style2">
						<header>
							<h2>VR Interprise</h2>
							<p>Marketing Digital</p>
						</header>
					</section>

				<!-- Three -->
					<section id="three" class="wrapper">
						<div class="spotlight">
							
							<div class="inner">
								<h3>Vinicius Rodrigues</h3>
								<p class="descricao">Seja bem vindo. Meu nome é Vinicius, tenho 20, anos e trabalho á 5, anos na área de publicidade e propaganda onde conheci o marketing digital. <br></p>
								<form class="form-contato" method="POST"> 
									
									
									<p class="descricao-p"> 
										<strong>Nome:</strong><br /> 
										<input type="text" class="input-form" size="30" name="nome"> 
                                    </p>   
									
									<p class="descricao-p">
										<strong>E-mail:</strong><br /> 
										<input type="text" class="input-form" size="30" name="email"> 
                                    </p> 
                                    
                                    <p class="descricao-p"> 
										<strong>Assunto</strong><br /> 
										<input type="text" class="input-form" size="30" name="assunto"> 
                                    </p> 
                                    
                                    <p class="descricao-p"> 
										<strong>Mensagem</strong><br /> 
										<input type="text" class="input-form" size="30" name="mensagem"> 
									</p> 

									<p class="descricao-p"> 
										<input type="submit" class="botao-form" name="BTEnvia" value="Enviar"> 
									</p> 
								</form> 
							</div>
						</div>
						
					</section>

				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-envelope-o"><span class="label">Email</span></a></li>
					</ul>
				</div>
				<div class="copyright">
					&copy;Vinicius Rodrigues Marketing Digital <a href="#">Desenvolvedor: </a>
				</div>
			</footer>
	</body>
</html>